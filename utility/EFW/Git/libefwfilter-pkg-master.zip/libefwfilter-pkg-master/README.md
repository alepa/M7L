# libefwfilter-pkg
Linux packaging scripts etc. for libEFWFilter, the ZWO filter wheel SDK
